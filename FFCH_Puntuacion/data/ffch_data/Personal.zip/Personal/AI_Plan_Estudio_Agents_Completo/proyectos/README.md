# Proyectos de Agents – Code Agent & Trading Agent

Documentación y esqueletos de código para los dos proyectos avanzados del plan de estudio.

---

## Estructura de carpetas

```
proyectos/
├── README.md                  ← este archivo
├── code_agent/
│   └── code_agent.py          ← esqueleto completo listo para ejecutar
└── trading_agent/
    └── trading_agent.py       ← esqueleto multi-agente listo para ejecutar
```

---

## 1. Code Agent con ejecución real

### ¿Qué hace?
Recibe una tarea de programación en lenguaje natural, genera código Python, lo ejecuta de forma segura, observa el resultado o el error y se corrige a sí mismo hasta conseguir una solución correcta (o agotar el número máximo de intentos).

### Patrones que practicas
- **ReAct** (Reason + Act)
- **Self-correction / Reflection**
- **Tool Use** (ejecutor de código)
- Estado + memoria de intentos anteriores
- Límites de seguridad (`max_attempts`, timeout)

### Arquitectura (LangGraph)

```
planner → code_generator → executor → critic
                ↑                        │
                └──── (si falla y quedan intentos) ────┘
                         ↓
                       END (success | failed)
```

### Estado principal

```python
class CodeAgentState(TypedDict):
    task: str
    current_code: str
    execution_result: str
    error_message: str
    attempt: int
    max_attempts: int
    history: list          # historial de intentos
    final_solution: str | None
    status: Literal["running", "success", "failed"]
```

### Cómo ejecutarlo

```bash
cd proyectos/code_agent
pip install langgraph langchain-openai langchain-anthropic python-dotenv

# Crea un .env con:
# OPENAI_API_KEY=sk-...
# o ANTHROPIC_API_KEY=sk-ant-...

python code_agent.py
```

Por defecto resuelve un factorial con asserts. Cambia la variable `task` al final del archivo para probar otras cosas.

### Mejoras recomendadas (después del MVP)
1. Sustituir `subprocess` por un sandbox real (e2b.dev, Modal, Docker).
2. Añadir tool de búsqueda web para cuando el agente se atasque.
3. Permitir multi-file (read/write/list files).
4. Versión Test-Driven: primero genera tests, luego el código que los pase.
5. Añadir Human-in-the-loop después de N fallos.

### Criterios de éxito
- Resuelve ≥ 70-80 % de tareas simples en ≤ 3 intentos
- Nunca ejecuta código peligroso
- Deja historial claro de lo que intentó y por qué falló
- Código final legible

**Tiempo estimado**
- MVP funcional: 8-15 h
- Versión sólida: 20-30 h

---

## 2. Agente de Trading / Análisis financiero

### ¿Qué hace?
Sistema multi-agente que analiza un activo (datos de precio + noticias + indicadores técnicos) y genera un informe diario profesional en Markdown.

**⚠️ Disclaimer importante**  
Este proyecto es **solo para aprendizaje**.  
Nunca conectes APIs de brokers reales ni operes con dinero real.  
El valor está en el sistema de agentes, no en “ganar dinero”.

### Patrones que practicas
- Multi-agent orchestration (flujo secuencial de especialistas)
- Tool Use (yfinance + noticias)
- Reflection / Critique (implícita en el writer)
- Structured output (Markdown bien formado)

### Arquitectura

```
market_data → news → sentiment_technical → analyst → report_writer → END
```

Versión más simple (MVP de 1 solo agente):  
Un único nodo que llama a las tools y escribe el informe.

### Estado principal

```python
class TradingState(TypedDict):
    symbol: str
    timeframe: str
    price_data: dict
    news: list
    sentiment_summary: str
    technical_summary: str
    thesis: str
    risks: list
    final_report: str
    messages: list
    status: Literal["running", "success", "failed"]
```

### Cómo ejecutarlo

```bash
cd proyectos/trading_agent
pip install langgraph langchain-openai yfinance pandas python-dotenv tavily-python

# .env necesario:
# OPENAI_API_KEY=sk-...
# TAVILY_API_KEY=tvly-...   (para noticias reales)

python trading_agent.py
```

Por defecto analiza `AAPL` en timeframe `3mo`. Cambia las variables `symbol` y `timeframe` al final del archivo.

El informe se imprime en consola y se guarda automáticamente como `report_AAPL_YYYYMMDD.md`.

### Estructura del informe generado

```markdown
# Análisis Diario – AAPL – 2026-11-04

## Resumen ejecutivo
## Datos de mercado
## Noticias y sentimiento
## Tesis principal
## Riesgos y escenarios
## Conclusión / Bias
```

### Mejoras recomendadas (después del MVP)
1. Convertir el flujo en un verdadero supervisor + workers paralelos.
2. Añadir más indicadores (MACD, Bollinger, volumen relativo).
3. Guardar históricos y comparar “qué dije la semana pasada”.
4. Interfaz Streamlit/Gradio para elegir símbolo.
5. Alertas cuando se cumplan condiciones (RSI < 30 + noticia positiva).
6. Versión multi-activo (swarm) que analice varios símbolos a la vez.

### Criterios de éxito
- Informe coherente y útil (no solo copy-paste de noticias)
- Separa claramente datos objetivos de interpretación
- Nunca recomienda “compra/vende” de forma definitiva
- El sistema no se rompe con símbolos raros
- Código limpio y tools bien encapsuladas

**Tiempo estimado**
- MVP (1 agente): 6-10 h
- Versión multi-agent sólida: 20-35 h
- Con interfaz + histórico: 40+ h

---

## Recomendación de orden

1. Empieza por el **Code Agent** (más autocontenido, menos dependencias externas).
2. Cuando domines el loop de self-correction, pasa al **Trading Agent**.
3. En ambos casos: haz primero el MVP de un solo agente y luego añade complejidad (más nodos, más tools, más robustez).

---

## Tips generales

- Usa **LangSmith** (gratis en el plan básico) para ver los traces de cada ejecución.
- Documenta en el README de tu repo las decisiones de diseño y los fallos que encontraste. Eso vale mucho en portfolio.
- Empieza siempre con tareas / símbolos sencillos y ve subiendo dificultad.
- No intentes hacer la versión “perfecta” de entrada. El aprendizaje real está en iterar.

¡Éxito construyendo!
