"""
Code Agent con ejecución real + self-correction
================================================
Esqueleto listo para empezar (LangGraph).

Objetivo:
  Recibe una tarea de programación en lenguaje natural,
  genera código Python, lo ejecuta de forma segura,
  observa el resultado/error y se corrige hasta lograr
  una solución correcta (o agotar max_attempts).

Requisitos:
  pip install langgraph langchain-openai langchain-anthropic python-dotenv

Uso rápido:
  1. Copia este archivo
  2. Configura tu API key en .env (OPENAI_API_KEY o ANTHROPIC_API_KEY)
  3. Ajusta la tool de ejecución según tu entorno (subprocess / Docker / e2b)
  4. Ejecuta: python code_agent.py
"""

from __future__ import annotations

import operator
import subprocess
import tempfile
import textwrap
from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.graph import END, StateGraph
from langgraph.prebuilt import ToolNode

load_dotenv()

# ---------------------------------------------------------------------------
# 1. Estado del grafo
# ---------------------------------------------------------------------------

class CodeAgentState(TypedDict):
    """Estado compartido que viaja entre todos los nodos."""
    task: str                          # Tarea original en lenguaje natural
    current_code: str                  # Último código generado
    execution_result: str              # stdout + stderr de la última ejecución
    error_message: str                 # Mensaje de error limpio (si hubo)
    attempt: int                       # Número de intento actual (empieza en 1)
    max_attempts: int                  # Límite de reintentos
    history: Annotated[list, operator.add]  # Historial de intentos (código + error)
    final_solution: str | None         # Código final cuando tiene éxito
    status: Literal["running", "success", "failed"]


# ---------------------------------------------------------------------------
# 2. Tool de ejecución segura
# ---------------------------------------------------------------------------

@tool
def execute_python_code(code: str) -> str:
    """
    Ejecuta código Python de forma relativamente segura.
    Devuelve stdout + stderr + código de retorno.

    NOTA DE SEGURIDAD:
    - Esta implementación usa subprocess con timeout.
    - En producción usa un sandbox real (Docker, e2b.dev, Modal, Firecracker…).
    - Nunca ejecutes código no confiable sin aislamiento.
    """
    # Limpiamos el código de posibles bloques markdown
    clean_code = code.strip()
    if clean_code.startswith("```python"):
        clean_code = clean_code[9:]
    if clean_code.startswith("```"):
        clean_code = clean_code[3:]
    if clean_code.endswith("```"):
        clean_code = clean_code[:-3]
    clean_code = clean_code.strip()

    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(clean_code)
            temp_path = f.name

        result = subprocess.run(
            ["python", temp_path],
            capture_output=True,
            text=True,
            timeout=10,  # segundos
        )

        output = []
        if result.stdout:
            output.append(f"STDOUT:\n{result.stdout}")
        if result.stderr:
            output.append(f"STDERR:\n{result.stderr}")
        output.append(f"RETURN_CODE: {result.returncode}")

        return "\n".join(output)

    except subprocess.TimeoutExpired:
        return "ERROR: Timeout (el código tardó más de 10 segundos)"
    except Exception as e:
        return f"ERROR de ejecución: {type(e).__name__}: {e}"


# ---------------------------------------------------------------------------
# 3. Nodos del grafo
# ---------------------------------------------------------------------------

def get_llm():
    """Devuelve el LLM que quieras usar. Cambia aquí fácilmente."""
    # Opción A – OpenAI
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(model="gpt-4o", temperature=0)

    # Opción B – Anthropic (descomenta y comenta la de arriba)
    # from langchain_anthropic import ChatAnthropic
    # return ChatAnthropic(model="claude-sonnet-4-20250514", temperature=0)


def planner_node(state: CodeAgentState) -> dict:
    """Entiende la tarea y prepara el contexto inicial."""
    return {
        "attempt": 1,
        "status": "running",
        "history": [],
        "final_solution": None,
        "current_code": "",
        "execution_result": "",
        "error_message": "",
    }


def code_generator_node(state: CodeAgentState) -> dict:
    """Genera (o regenera) el código Python."""
    llm = get_llm()

    system_prompt = textwrap.dedent("""
        Eres un experto programador Python.
        Tu única misión es escribir código Python que resuelva la tarea del usuario.

        Reglas:
        - Responde ÚNICAMENTE con el código Python (puedes usar bloques ```python).
        - No escribas explicaciones fuera del código.
        - Si hay un error anterior, léelo con atención y corrígelo.
        - Añade prints o asserts que permitan verificar que la solución es correcta.
        - El código debe ser autocontenido y ejecutable.
    """).strip()

    messages = [SystemMessage(content=system_prompt)]

    # Contexto de la tarea
    messages.append(HumanMessage(content=f"Tarea:\n{state['task']}"))

    # Si hay intentos previos, mostramos el historial
    if state.get("history"):
        history_text = "\n\n--- Intentos anteriores ---\n"
        for i, h in enumerate(state["history"], 1):
            history_text += f"\nIntento {i}:\nCódigo:\n{h.get('code', '')}\nResultado:\n{h.get('result', '')}\n"
        messages.append(HumanMessage(content=history_text))
        messages.append(HumanMessage(
            content="Corrige el código basándote en los errores anteriores. Genera una nueva versión completa."
        ))

    response = llm.invoke(messages)
    code = response.content

    return {
        "current_code": code,
        "attempt": state["attempt"],
    }


def executor_node(state: CodeAgentState) -> dict:
    """Ejecuta el código actual y guarda el resultado."""
    result = execute_python_code.invoke({"code": state["current_code"]})

    # Determinamos si hubo error
    error = ""
    if "RETURN_CODE: 0" not in result or "ERROR" in result or "STDERR:" in result:
        # Extraemos un mensaje de error más limpio
        if "STDERR:" in result:
            error = result.split("STDERR:")[-1].split("RETURN_CODE")[0].strip()
        else:
            error = result

    return {
        "execution_result": result,
        "error_message": error,
    }


def critic_node(state: CodeAgentState) -> dict:
    """Decide si el resultado es éxito o hay que reintentar."""
    success = (
        "RETURN_CODE: 0" in state["execution_result"]
        and "ERROR" not in state["execution_result"]
        and not state["error_message"]
    )

    # Guardamos el intento en el historial
    history_entry = {
        "code": state["current_code"],
        "result": state["execution_result"],
        "error": state["error_message"],
    }

    if success:
        return {
            "status": "success",
            "final_solution": state["current_code"],
            "history": [history_entry],
        }

    # Si falló y aún quedan intentos
    next_attempt = state["attempt"] + 1
    if next_attempt > state["max_attempts"]:
        return {
            "status": "failed",
            "history": [history_entry],
        }

    return {
        "status": "running",
        "attempt": next_attempt,
        "history": [history_entry],
    }


def should_continue(state: CodeAgentState) -> Literal["code_generator", "__end__"]:
    """Arista condicional: ¿seguimos intentando o terminamos?"""
    if state["status"] in ("success", "failed"):
        return "__end__"
    return "code_generator"


# ---------------------------------------------------------------------------
# 4. Construcción del grafo
# ---------------------------------------------------------------------------

def build_code_agent():
    graph = StateGraph(CodeAgentState)

    graph.add_node("planner", planner_node)
    graph.add_node("code_generator", code_generator_node)
    graph.add_node("executor", executor_node)
    graph.add_node("critic", critic_node)

    graph.set_entry_point("planner")
    graph.add_edge("planner", "code_generator")
    graph.add_edge("code_generator", "executor")
    graph.add_edge("executor", "critic")
    graph.add_conditional_edges("critic", should_continue)

    return graph.compile()


# ---------------------------------------------------------------------------
# 5. Ejecución de ejemplo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    agent = build_code_agent()

    # --- Cambia esta tarea por la que quieras ---
    task = """
    Escribe una función llamada `factorial(n)` que calcule el factorial de n.
    Debe funcionar para n >= 0.
    Incluye al final del archivo varias aserciones (assert) que verifiquen:
    - factorial(0) == 1
    - factorial(1) == 1
    - factorial(5) == 120
    - factorial(7) == 5040
    """

    print("=" * 60)
    print("CODE AGENT – Iniciando")
    print("=" * 60)
    print(f"Tarea:\n{task.strip()}\n")

    initial_state = {
        "task": task.strip(),
        "max_attempts": 5,
        # el resto se inicializa en planner_node
        "current_code": "",
        "execution_result": "",
        "error_message": "",
        "attempt": 0,
        "history": [],
        "final_solution": None,
        "status": "running",
    }

    final_state = agent.invoke(initial_state)

    print("\n" + "=" * 60)
    print(f"Resultado final: {final_state['status'].upper()}")
    print(f"Intentos usados: {final_state['attempt']}")
    print("=" * 60)

    if final_state["status"] == "success":
        print("\n✅ Código final:\n")
        print(final_state["final_solution"])
    else:
        print("\n❌ No se encontró solución dentro del límite de intentos.")
        print("\nÚltimo error:")
        print(final_state.get("error_message", "N/A"))
