"""
Agente de Trading / Análisis financiero (solo análisis, NO opera dinero real)
==============================================================================
Esqueleto multi-agente con LangGraph.

Objetivo:
  Analizar un activo (noticias + datos de precio + indicadores)
  y generar un informe diario de calidad en Markdown.

⚠️  DISCLAIMER:
  Este proyecto es ÚNICAMENTE para aprendizaje.
  Nunca conectes APIs de brokers reales ni operes con dinero real.
  El valor está en el sistema de agentes, no en "ganar dinero".

Requisitos:
  pip install langgraph langchain-openai langchain-anthropic yfinance
              pandas python-dotenv tavily-python

Uso rápido:
  1. Configura OPENAI_API_KEY (o ANTHROPIC_API_KEY) y TAVILY_API_KEY en .env
  2. Ejecuta: python trading_agent.py
"""

from __future__ import annotations

import json
import operator
import textwrap
from datetime import datetime
from typing import Annotated, Literal, TypedDict

import yfinance as yf
from dotenv import load_dotenv
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.graph import END, StateGraph

load_dotenv()

# ---------------------------------------------------------------------------
# 1. Estado compartido
# ---------------------------------------------------------------------------

class TradingState(TypedDict):
    symbol: str
    timeframe: str                     # ej. "1mo", "3mo", "1y"
    price_data: dict                   # resumen de precios + indicadores
    news: list                         # lista de noticias
    sentiment_summary: str
    technical_summary: str
    thesis: str
    risks: list
    final_report: str
    messages: Annotated[list, operator.add]
    status: Literal["running", "success", "failed"]


# ---------------------------------------------------------------------------
# 2. Tools
# ---------------------------------------------------------------------------

@tool
def get_price_data(symbol: str, period: str = "1mo") -> str:
    """
    Obtiene datos de precio (OHLCV) y calcula indicadores básicos
    usando yfinance. Devuelve un resumen en texto/JSON.
    """
    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=period)

        if df.empty:
            return json.dumps({"error": f"No se encontraron datos para {symbol}"})

        # Indicadores simples
        df["SMA_20"] = df["Close"].rolling(window=20).mean()
        df["SMA_50"] = df["Close"].rolling(window=50).mean() if len(df) >= 50 else None

        # RSI aproximado (14 periodos)
        delta = df["Close"].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df["RSI"] = 100 - (100 / (1 + rs))

        last = df.iloc[-1]
        prev = df.iloc[-2] if len(df) > 1 else last

        summary = {
            "symbol": symbol,
            "period": period,
            "last_close": round(float(last["Close"]), 2),
            "previous_close": round(float(prev["Close"]), 2),
            "change_pct": round(((last["Close"] - prev["Close"]) / prev["Close"]) * 100, 2),
            "volume": int(last["Volume"]),
            "high_period": round(float(df["High"].max()), 2),
            "low_period": round(float(df["Low"].min()), 2),
            "sma_20": round(float(last["SMA_20"]), 2) if last["SMA_20"] == last["SMA_20"] else None,
            "rsi_14": round(float(last["RSI"]), 2) if last["RSI"] == last["RSI"] else None,
            "data_points": len(df),
        }
        return json.dumps(summary, indent=2)

    except Exception as e:
        return json.dumps({"error": str(e)})


@tool
def get_news(query: str, max_results: int = 6) -> str:
    """
    Busca noticias recientes relacionadas con el activo o sector.
    Usa Tavily (recomendado) o un fallback simple.
    """
    try:
        from tavily import TavilyClient
        import os

        client = TavilyClient(api_key=os.getenv("TAVILY_API_KEY"))
        response = client.search(
            query=query,
            topic="news",
            max_results=max_results,
            days=7,
        )

        articles = []
        for r in response.get("results", []):
            articles.append({
                "title": r.get("title"),
                "url": r.get("url"),
                "content": r.get("content", "")[:400],
                "published_date": r.get("published_date"),
            })
        return json.dumps(articles, indent=2, ensure_ascii=False)

    except Exception as e:
        # Fallback muy simple si no hay Tavily
        return json.dumps([
            {
                "title": f"[Fallback] No se pudo obtener noticias reales: {e}",
                "url": "",
                "content": "Configura TAVILY_API_KEY para noticias reales.",
                "published_date": None,
            }
        ])


# ---------------------------------------------------------------------------
# 3. Nodos (agentes)
# ---------------------------------------------------------------------------

def get_llm():
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(model="gpt-4o", temperature=0.2)
    # from langchain_anthropic import ChatAnthropic
    # return ChatAnthropic(model="claude-sonnet-4-20250514", temperature=0.2)


def market_data_node(state: TradingState) -> dict:
    """Obtiene y resume los datos de mercado."""
    raw = get_price_data.invoke({
        "symbol": state["symbol"],
        "period": state.get("timeframe", "1mo"),
    })
    return {"price_data": json.loads(raw)}


def news_node(state: TradingState) -> dict:
    """Busca noticias relevantes."""
    query = f"{state['symbol']} stock news OR earnings OR analysis"
    raw = get_news.invoke({"query": query, "max_results": 6})
    return {"news": json.loads(raw)}


def sentiment_and_technical_node(state: TradingState) -> dict:
    """Analiza sentimiento de noticias + interpreta los datos técnicos."""
    llm = get_llm()

    prompt = textwrap.dedent(f"""
        Eres un analista financiero cuantitativo y de sentimiento.

        Datos de mercado:
        {json.dumps(state['price_data'], indent=2)}

        Noticias recientes:
        {json.dumps(state['news'], indent=2, ensure_ascii=False)}

        Tareas:
        1. Resume el sentimiento general de las noticias (bullish / bearish / neutral) 
           y explica brevemente por qué.
        2. Interpreta los indicadores técnicos (precio vs SMA, RSI, etc.) 
           en 3-5 frases claras.

        Responde en este formato exacto:

        SENTIMENT:
        <tu resumen de sentimiento>

        TECHNICAL:
        <tu resumen técnico>
    """).strip()

    response = llm.invoke([HumanMessage(content=prompt)])
    content = response.content

    sentiment = ""
    technical = ""
    if "SENTIMENT:" in content and "TECHNICAL:" in content:
        parts = content.split("TECHNICAL:")
        sentiment = parts[0].replace("SENTIMENT:", "").strip()
        technical = parts[1].strip()
    else:
        sentiment = content
        technical = content

    return {
        "sentiment_summary": sentiment,
        "technical_summary": technical,
    }


def analyst_node(state: TradingState) -> dict:
    """Genera la tesis principal y la lista de riesgos."""
    llm = get_llm()

    prompt = textwrap.dedent(f"""
        Eres un analista senior de equity research.

        Activo: {state['symbol']}
        Datos de mercado: {json.dumps(state['price_data'], indent=2)}
        Sentimiento: {state['sentiment_summary']}
        Técnico: {state['technical_summary']}

        Genera:
        1. Una tesis principal clara (2-4 párrafos) que combine datos + noticias.
        2. Una lista de 3-5 riesgos principales.

        Formato de respuesta:

        THESIS:
        <tesis>

        RISKS:
        - riesgo 1
        - riesgo 2
        - ...
    """).strip()

    response = llm.invoke([HumanMessage(content=prompt)])
    content = response.content

    thesis = ""
    risks = []
    if "THESIS:" in content and "RISKS:" in content:
        parts = content.split("RISKS:")
        thesis = parts[0].replace("THESIS:", "").strip()
        risks_raw = parts[1].strip()
        risks = [r.strip("- ").strip() for r in risks_raw.split("\n") if r.strip()]
    else:
        thesis = content
        risks = ["No se pudieron extraer riesgos estructurados"]

    return {
        "thesis": thesis,
        "risks": risks,
    }


def report_writer_node(state: TradingState) -> dict:
    """Escribe el informe final en Markdown + hace una pequeña reflection."""
    llm = get_llm()

    today = datetime.now().strftime("%Y-%m-%d")

    prompt = textwrap.dedent(f"""
        Eres un escritor de research notes profesional.

        Genera un informe diario completo en Markdown para el activo {state['symbol']}.
        Fecha: {today}

        Datos disponibles:
        - Precio / indicadores: {json.dumps(state['price_data'], indent=2)}
        - Sentimiento: {state['sentiment_summary']}
        - Técnico: {state['technical_summary']}
        - Tesis: {state['thesis']}
        - Riesgos: {state['risks']}

        Estructura obligatoria del informe:

        # Análisis Diario – {state['symbol']} – {today}

        ## Resumen ejecutivo
        (3-5 frases)

        ## Datos de mercado
        (precio, variación, volumen, indicadores clave)

        ## Noticias y sentimiento
        (resumen + sesgo)

        ## Tesis principal
        (la tesis del analista)

        ## Riesgos y escenarios
        (lista clara)

        ## Conclusión / Bias
        (solo informativo – NUNCA digas "compra" o "vende" de forma definitiva.
         Usa lenguaje del tipo "sesgo constructivo / cauteloso / neutral")

        Escribe en español, tono profesional y objetivo.
    """).strip()

    response = llm.invoke([HumanMessage(content=prompt)])
    report = response.content

    return {
        "final_report": report,
        "status": "success",
    }


# ---------------------------------------------------------------------------
# 4. Grafo
# ---------------------------------------------------------------------------

def build_trading_agent():
    graph = StateGraph(TradingState)

    graph.add_node("market_data", market_data_node)
    graph.add_node("news", news_node)
    graph.add_node("sentiment_technical", sentiment_and_technical_node)
    graph.add_node("analyst", analyst_node)
    graph.add_node("report_writer", report_writer_node)

    graph.set_entry_point("market_data")
    graph.add_edge("market_data", "news")
    graph.add_edge("news", "sentiment_technical")
    graph.add_edge("sentiment_technical", "analyst")
    graph.add_edge("analyst", "report_writer")
    graph.add_edge("report_writer", END)

    return graph.compile()


# ---------------------------------------------------------------------------
# 5. Ejecución de ejemplo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    agent = build_trading_agent()

    symbol = "AAPL"          # Cambia por el símbolo que quieras
    timeframe = "3mo"

    print("=" * 60)
    print(f"TRADING AGENT – Analizando {symbol}")
    print("=" * 60)

    initial_state = {
        "symbol": symbol,
        "timeframe": timeframe,
        "price_data": {},
        "news": [],
        "sentiment_summary": "",
        "technical_summary": "",
        "thesis": "",
        "risks": [],
        "final_report": "",
        "messages": [],
        "status": "running",
    }

    final_state = agent.invoke(initial_state)

    print("\n" + final_state["final_report"])
    print("\n" + "=" * 60)
    print("Análisis completado")
    print("=" * 60)

    # Guardar el informe
    filename = f"report_{symbol}_{datetime.now().strftime('%Y%m%d')}.md"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(final_state["final_report"])
    print(f"\nInforme guardado en: {filename}")
