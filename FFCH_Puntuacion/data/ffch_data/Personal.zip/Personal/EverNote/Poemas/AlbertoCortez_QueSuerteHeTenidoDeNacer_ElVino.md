# 👤 Alberto Córtez

## 📖 Qué suerte he tenido de nacer

> *Qué suerte he tenido de nacer,*    
> *para estrechar la mano de un amigo*    
> *y poder asistir como testigo*    
> *al milagro de cada amanecer.*    

> *Qué suerte he tenido de nacer,*    
> *para tener la opción de la balanza,*    
> *sopesar la derrota y la esperanza*    
> *con la gloria y el miedo de caer.*    

> *Qué suerte he tenido de nacer,*    
> *para entender que el honesto y el perverso*    
> *son dueños por igual del universo*    
> *aunque tengan distinto parecer.*    

> *Qué suerte he tenido de nacer,*    
> *para callar cuando habla el que más sabe,*    
> *aprender a escuchar, ésa es la clave,*    
> *si se tiene intenciones de saber.*    

> *Qué suerte he tenido de nacer,*    
> *y lo digo sin falsos triunfalismos,*    
> *la victoria total, la de uno mismo,*    
> *se concreta en el ser y en el no ser.*    

> *Qué suerte he tenido de nacer,*    
> *para cantarle a la gente y a la rosa*    
> *y al perro y al amor y a cualquier cosa*    
> *que pueda el sentimiento recoger.*    

> *Qué suerte he tenido de nacer,*    
> *para tener acceso a la fortuna*    
> *de ser río en lugar de ser laguna,*    
> *de ser lluvia en lugar de ver llover.*    

> *Qué suerte he tenido de nacer,*    
> *para comer a conciencia la manzana,*    
> *sin el miedo ancestral a la sotana*    
> *ni a la venganza final de Lucifer.*    

> *Pero sé, bien que sé...*    
> *que algún día también me moriré.*    
> *Si ahora vivo contento con mi suerte,*    
> *sabe Dios qué pensaré cuando mi muerte,*    
> *cuál será en la agonía mi balance, no lo sé,*    
> *nunca estuve en ese trance.*    

> *Pero sé, bien que sé...*    
> *que en mi viaje final escucharé*    
> *el ambiguo tañir de las campanas*    
> *saludando mi adiós, y otra mañana*    
> *y otra voz, como yo, con otro acento,*    
> *cantará a los cuatro vientos...*    
> *Qué suerte he tenido de nacer.*    

- Pasted from <http://www.albertocortez.com/poemas/home.asp?Id=89>

---

## 📖 El Vino

> *Sí señor... el vino puede sacar*    
> *cosas que el hombre se calla;*    
> *que deberían salir*    
> *cuando el hombre bebe agua.*    

> *Va buscando, pecho adentro,*    
> *por los silencios del alma*    
> *y les va poniendo voces*    
> *y los va haciendo palabras.*    

> *A veces saca una pena,*    
> *que por ser pena, es amarga;*    
> *sobre su palco de fuego,*    
> *la pone a bailar descalza.*    

> *Baila y bailando se crece,*    
> *hasta que el vino se acaba*    
> *y entonces, vuelve la pena*    
> *a ser silencio del alma.*    

> *El vino puede sacar*    
> *cosas que el hombre se calla.*    

> *Cosas que queman por dentro,*    
> *cosas que pudren el alma*    
> *de los que bajan los ojos,*    
> *de los que esconden la cara.*    

> *El vino entonces, libera*    
> *la valentía encerrada*    
> *y los disfraza de machos,*    
> *como por arte de magia...*    

> *Y entonces, son bravucones,*    
> *hasta que el vino se acaba*    
> *pues del matón al cobarde,*    
> *solo media, la resaca.*    

> *El vino puede sacar*    
> *cosas que el hombre se calla.*    

> *Cambia el prisma de las cosas*    
> *cuando más les hace falta*    
> *a los que llevan sus culpas*    
> *como una cruz a la espalda.*    

> *La puta se piensa pura,*    
> *como cuando era muchacha*    
> *y el cornudo regatea*    
> *la medida de sus astas.*    

> *Y todo tiene colores*    
> *de castidad, simulada,*    
> *pues siempre acaban el vino*    
> *los dos, en la misma cama.*    

> *El vino puede sacar*    
> *cosas que el hombre se calla.*    

> *Pero... ¡qué lindo es el vino!*    
> *El que se bebe en la casa*    
> *del que está limpio por dentro*    
> *y tiene brillando el alma.*    

> *Que nunca le tiembla el pulso,*    
> *cuando pulsa una guitarra.*    
> *Que no le falta un amigo*    
> *ni noches para gastarlas.*    


> *Que cuando tiene un pecado,*    
> *siempre se nota en su cara...*    
> *Que bebe el vino por vino*    
> *y bebe el agua, por agua.*    
