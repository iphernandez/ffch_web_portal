# 👤 José Joaquín de Olmedo

## 📖 Alfabeto para un niño

> *AMOR de patria comprende*  
> *cuanto el hombre debe amar:*  
> *Su Dios, sus leyes, su hogar,*  
> *y el honor que los defiende.*  
 
> *BONDAD, el que la merece*  
>  *con ánimo siempre igual,*  
>  *ni se abate con el mal,*  
>  *ni en el bien se ensóbrese.*  

> *CANDOR en toda expresión,*  
> *callar lo más que pudieres;*  
> *muy cortés con las mujeres,*  
> *pero sin afectación.*  

> *DIOS es el sabio creador*  
> *que conserva y ama al hombre,*  
> *sea cual fuere su nombre,*  
> *condición, secta y color.*  

> *ESTUDIO y aplicación*  
> *forman a la juventud,*  
> *y emulación de virtud*  
> *sin envidia ni ambición.*  

> *FRANQUEZA, nunca indecencia,*  
> *usa en la conversación;*  
> *disimulo y no ficción;*  
> *libertad, nunca licencia.*  

> *GRATITUD siempre al favor*  
> *es un deber justo y grato;*  
> *y es por eso el hombre ingrato*  
> *es un monstruo que da horror.*  

> *HONOR es en sumo grado*  
> *el alma del ciudadano:*  
> *sin honor es miembro vano,*  
> *o pernicioso al Estado.*  

> *IRA hace al hombre un tirano*  
> *de inferiores y de iguales:*  
> *la ira es propia de animales,*  
> *porque no es afecto humano.*  

> *JUEGO es una diversión honesto, si es moderado;*  
> *pero si es inmoderado*  
> *causa nuestra perdición.*  

> *LIBERTAD ¡oh dulce nombre!*  
> *hermoso y celeste don:*  
> *tú eres la misma razón,*  
> *tú eres el alma del hombre.*  

> *MORAL, la sana moral*  
> *consiste en amarse bien,*  
> *en hacer a todos bien,*  
> *y en no hacer a nadie mal.*  

> *NATURALEZA sagaz*  
> *llena y rige al universo:*  
> *todo está bien; el perverso*  
> *solamente está de más.*  

> *ORO es un bien apreciable*  
> *para el cómodo sustento;*  
> *pero es el mayor tormento*  
> *la sed de oro insaciable.*  

> *PEREZA es enfermedad*  
> *tan mala como la muerte;*  
> *así no cabe el inerte*  
> *en ninguna sociedad.*  

> *QUIJOTERÍA es un vicio*  
> *que causa risa y desprecio,*  
> *pues es un quijote necio*  
> *corre aventuras el juicio.*  

> *RESPETO a los superiores,*  
> *respeto y amor al padre,*  
> *amor, ternura a la madre,*  
> *reverencia a los mayores.*  

> *SOCIEDAD es el estado*  
> *en que con otro vivieres,*  
> *y serás social si fueres*  
> *justo, modesto y aseado.*  

> *TIRANÍA y opresión*  
> *suenan y expresan lo mismo:*  
> *para salir de este abismo*  
> *es honrosa toda acción.*  

> *VENGANZA, nunca jamás:*  
> *nunca, nunca odio o rencor;*  
> *porque no hay placer mayor*  
> *como amar y perdonar.*  

> *YO debo ser el primero*  
> *para mi conservación;*  
> *mas por buena educación*  
> *en sociedad el postrero.*  

> *ZELO en cumplir su deber*  
> *en cualquier condición,*  
> *será la única ambición*  
> *que un niño debe tener.*  

> *Estas reglas niño amado,*  
> *te harán un niño gracioso,*  
> *un joven pundonoroso,*  
> *un hombre bueno y honrado*  
> *y un anciano respetado*  
> *que a sus iguales auxilia,*  
> *sus diferencias concilia,*  
> *con bondad, no con rigor,*  
> *y muere siendo el honor*  
> *de su patria y su familia.*  

- **Obtenido de "http://es.wikisource.org/wiki/Alfabeto_para_un_ni%C3%B1o"**  

  