# 👤 Pedro B. Palacios - Almafuerte

## 📖 ¡AVANTI!

> *Si te postran diez veces, te levantas*    
> *otras diez, otras cien, otras quinientas:*    
> *no han de ser tus caídas tan violentas*    
> *ni tampoco, por ley, han de ser tantas.*    
> *Con el hambre genial con que las plantas*    
> *asimilan el humus avarientas,*    
> *deglutiendo el rencor de las afrentas*    
> *se formaron los santos y las santas.*    
> *Obsesión casi asnal, para ser fuerte,*    
> *nada más necesita la criatura,*    
> *y en cualquier infeliz se me figura*    
> *que se mellan los garfios de la suerte . . .*    
> *¡Todos los incurables tienen cura*    
> *cinco segundos antes de su muerte!*    
   
## 📖 ¡PIU AVANTI!
  
> *No te des por vencido, ni aun vencido,*    
> *no te sientas esclavo, ni aun esclavo;*    
> *trémulo de pavor, piénsate bravo,*    
> *y arremete feroz, ya mal herido.*    
> *Ten el tesón del clavo enmohecido*    
> *que ya viejo y ruin, vuelve a ser clavo;*    
> *no la cobarde estupidez del pavo*    
> *que amaina su plumaje al primer ruido.*    
> *Procede como Dios que nunca llora;*    
> *o como Lucifer, que nunca reza;*    
> *o como el robledal, cuya grandeza*    
> *necesita del agua y no la implora...*    
> *Que muerda y vocifere vengadora,*    
> *ya rodando en el polvo, tu cabeza!*    

## 📖 ¡MOLTO PIU AVANTI!

> *Los que vierten sus lágrimas amantes*    
> *sobre las penas que no son sus penas;*    
> *los que olvidan el son de sus cadenas*    
> *para limar las de los otros antes;*    
> *Los que van por el mundo delirantes*    
> *repartiendo su amor a manos llenas,*    
> *caen, bajo el peso de sus obras buenas,*    
> *sucios, enfermos, trágicos... ¡sobrantes!*    
> *¡Ah! ¡Nunca quieras remediar entuertos!*    
> *¡nunca sigas impulsos compasivos!*    
> *¡ten los garfios del Odio siempre activos*    
> *los ojos del juez siempre despiertos!*    
> *¡Y al echarte en la caja de los muertos,*    
> *menosprecia los llantos de los vivos!*    

## 📖 ¡MOLTO PIU AVANTI ANCORA!

> *El mundo miserable es un estrado*    
> *donde todo es estólido y fingido,*    
> *donde cada anfitrión guarda escondido*    
> *su verdadero ser, tras el tocado:*    
> *No digas tu verdad ni al más amado,*    
> *no demuestres temor ni al más temido,*    
> *no creas que jamás te hayan querido*    
> *por más besos de amor que te hayan dado.*    
> *Mira como la nieve se deslíe*    
> *sin que apostrofe al sol su labio yerto,*    
> *cómo ansía las nubes el desierto*    
> *sin que a ninguno su ansiedad confíe...*    
> *¡Trema como el infierno, pero ríe!*    
> *¡Vive la vida plena, pero muerto!*    

## 📖 ¡MOLTISSIMO PIU AVANTI ANCORA!

> *Si en vez de las estúpidas panteras*    
> *y los férreos estúpidos leones,*    
> *encerrasen dos flacos mocetones*    
> *en esa frágil cárcel de las fieras,*    
> *No habrían de yacer noches enteras*    
> *en el blando pajar de sus colchones,*    
> *sin esperanzas ya, sin reacciones*    
> *lo mismo que dos plácidos horteras;*    
> *Cual Napoleones pensativos, graves,*    
> *no como el tigre sanguinario y maula,*    
> *escrutarían palmo a palmo su aula,*    
> *buscando las rendijas, no las llaves...*    
> *¡Seas el que tú seas, ya lo sabes:*    
> *a escrutar las rendijas de tu jaula!*    

## 📖 VERA VIOLETA

> *En pos de su nivel se lanza el río*    
> *por el gran desnivel de los breñales;*    
> *el aire es vendaval, y hay vendavales*    
> *por la ley del no fin, del no vacío;*    
> *la más hermosa espiga del estío*    
> *ni sueña con el pan en los trigales;*    
> *el más dulce panal de los panales*    
> *no declaró jamás: yo no soy mío.*    
> *Y el sol, el padre sol, el raudo foco*    
> *que fomenta la vida en la Natura,*    
> *por calentar los polos no se apura,*    
> *ni se desvía un ápice tampoco:*    
> *¡Todo lo alcanzarás, solemne loco,*    
> *siempre que lo permita tu estatura!*    

## 📖 LA YAPA

> *Como una sola estrella no es el cielo,*    
> *ni una gota que salta, el Océano,*    
> *ni una falange rígida, la mano,*    
> *ni una brizna de paja, el santo suelo:*    
> *tu gimnasia de cárcel, no es el vuelo,*    
> *el sublime tramonto soberano,*    
> *ni nunca podrá ser anhelo humano*    
> *tu miserable personal anhelo.*    
> *¿Qué saben de lo eterno las esferas;*    
> *de las borrascas de la mar, la gota;*    
> *de puñetazos, la falange rota;*    
> *de harina y pan, la paja de las eras?...*    
> *¡Detente, por piedad, pluma no quieras*    
> *que abandone sus armas el idiota!*    
