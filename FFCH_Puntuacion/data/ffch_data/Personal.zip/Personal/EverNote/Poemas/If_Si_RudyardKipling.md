# 👤 Rudyard Kipling

## 📖 If...
 
> *If you can keep your head when all around you
> *Are losing theirs and blaming it on you;

> *If you can trust yourself when all men doubt you,
> *But make allowance for their doubting too;

> *If you can wait and not be tired by waiting,
> *Or, being lied about, don't deal in lies,
> *Or, being hated, don't give way to hating,
> *And yet don't look too good, nor talk too wise;

> *If you can dream—and not make dreams your master;
> *If you can think—and not make thoughts your aim;
> *If you can meet with triumph and disaster
> *And treat those two imposters just the same;
> *If you can bear to hear the truth you've spoken
> *Twisted by knaves to make a trap for fools,
> *Or watch the things you gave your life to broken,
> *And stoop and build 'em up with wornout tools;

> *If you can make one heap of all your winnings
> *And risk it on one turn of pitch-and-toss,
> *And lose, and start again at your beginnings
> *And never breathe a word about your loss;
> *If you can force your heart and nerve and sinew
> *To serve your turn long after they are gone,
> *And so hold on when there is nothing in you
> *Except the Will which says to them: "Hold on";

> *If you can talk with crowds and keep your virtue,
> *Or walk with kings—nor lose the common touch;
> *If neither foes nor loving friends can hurt you;
> *If all men count with you, but none too much;
> *If you can fill the unforgiving minute
> *With sixty seconds' worth of distance run

> *Yours is the Earth and everything that's in it,

> *And—which is more—you'll be a Man my son!

## 📖 Si...

> *Si puedes mantener en su lugar tu cabeza cuando todos a tu alrededor,
> *han perdido la suya y te culpan de ello.

> *Si crees en ti mismo cuando todo el mundo duda de ti,
> *pero también dejas lugar a sus dudas.

> *Si puedes esperar y no cansarte de la espera;
> *o si, siendo engañado, no respondes con engaños,
> *o si, siendo odiado, no te domina el odio
> *Y aún así no pareces demasiado bueno o demasiado sabio.

> *Si puedes soñar y no hacer de los sueños tu amo;
> *Si puedes pensar y no hacer de tus pensamientos tu único objetivo;
> *Si puedes conocer al triunfo y la derrota,
> *y tratar de la misma manera a esos dos impostores.
> *Si puedes soportar oír toda la verdad que has dicho,
> *tergiversada por malhechores para engañar a los necios.
> *O ver cómo se rompe todo lo que has creado en tu vida,
> *y agacharte para reconstruírlo con herramientas maltrechas.

> *Si puedes amontonar todo lo que has ganado
> *y arriesgarlo todo a un sólo lanzamiento ;
> *y perderlo, y empezar de nuevo desde el principio
> *y no decir ni una palabra sobre tu pérdida.
> *Si puedes forzar tu corazón y tus nervios y tus tendones,
> *para seguir adelante mucho después de haberlos perdido,
> *y resistir cuando no haya nada en ti
> *salvo la voluntad que te dice: "Resiste!".

> *Si puedes hablar a las masas y conservar tu virtud.
> *o caminar junto a reyes, y no distanciarte de los demás.
> *Si ni amigos ni enemigos pueden herirte.
> *Si todos cuentan contigo, pero ninguno demasiado.
> *Si puedes llenar el inexorable minuto,
> *con sesenta segundos que valieron la pena recorrer...

> *Todo lo que hay sobre La Tierra será tuyo,

> *y lo que es más: serás un hombre, hijo mío.

- **Pasted from <http://es.wikipedia.org/wiki/Si..._(Kipling)>**
