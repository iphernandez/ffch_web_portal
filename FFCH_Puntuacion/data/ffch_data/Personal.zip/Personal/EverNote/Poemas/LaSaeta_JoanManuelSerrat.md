# 👤 Joan Manuel Serrat

## 📖 La Saeta

> *Dijo una voz popular:*    
> *"¿Quién me presta una escalera para subir al madero*    
> *Para quitarle los clavos a Jesús, el Nazareno?"*    
> *Oh, la saeta al cantar*    
> *Al Cristo de los gitanos*    
> *Siempre con sangre en las manos*    
> *Siempre por desenclavar*    
> *Cantar del pueblo andaluz*    
> *Que todas las primaveras*    
> *Anda pidiendo escaleras*    
> *Para subir a la cruz*    
> *Cantar de la tierra mía*    
> *Que echa flores*    
> *Al Jesús de la agonía*    
> *Y es la fe de mis mayores*    
> *Oh, no eres tú mi cantar*    
> *No puedo cantar, ni quiero*    
> *A este Jesús del madero*    
> *Sino al que anduvo en la mar*    
> *Oh, no eres tú mi cantar*    
> *No puedo cantar, ni quiero*    
> *A ese Jesús del madero*    
> *Sino al que anduvo en la mar*    
> *Oh, no eres tú mi cantar*    
> *No puedo cantar, ni quiero*    
> *A ese Jesús del madero*    
> *Sino al que anduvo en la mar*    
> *Oh, no eres tú mi cantar*    