# 👤 Anonimo

## 📖 Pasión del fútbol

> *¿Porque juegas?  Me pregunto mi hijo*    
> *¿para qué vas, si ya no puedes jugar?*    
> *Para que pierdes tu tiempo*    
> *Si ya no te van a poner!!!!!!  Aseguro mi gordito*    
> *quédate conmigo a ver televisión mejor!!!*    

> *Quiero jugar hasta el día en que me muera,*    
> *Quiero jugar porque me crie así desde niño,*    
> *!!El fútbol lo era todo para mi generación!! ,*    

> *Jugare hasta el día que tenga aliento,*    
> *Quiero jugar un rato más, así sean pocos campeonatos,*    
> *Así sean pocos minutos, así sea viendo jugar a mis amigos*    
> *Estaré en una cancha de futbol, de futbolito, de mini fútbol*    
> *¡¡¡Nunca será para mi perder el tiempo estar en una cancha!!!*    
> *¡¡¡Jamás!!!*    

> *Estaré así sea para que me den 5 minutos o 1 en una cancha*    
> *Estaré ahí y me molestare, renegare, jodere,*    
> *Pero ahí estaré esperando mi oportunidad,*    
> *La oportunidad de sentirme vivo otra vez,*    
> *Dándole a un balón*    
> *Si no puedo jugar, estaré para alentar,*    
> *Para dirigir, para joder, para gritar*    
> *Mis hijos nunca entenderán esto,*    
> *¡¡¡No son mi generación!!!*    

> *Así me gane problemas con mis hijos,*    
> *Así me gane problemas con mi mujer*    
> *Así me gane problemas con mi vieja*    
> *Así me gane problemas con el trabajo*    
> *Saldré a distraerme*    
> *Saldré a jugar o a ver*    
> *Saldré con cualquier excusa, pero saldré*    
> *Que van a saber si para nosotros de niños*    
> *El regalo soñado era un balón de futbol,*    
> *Donde lo mejor del día era juntarte con los patas*    
> *Para darle al balón, donde esperabas que empezará*    
> *¡¡¡El campeonato del barrio para poder jugar, eso era todo!!!*    
> *Antes era difícil jugar en la liga*    
> *Era bravo representar a tu barrio*    
> *Y era más bravo ser "jale"*    
> *Mis hijos nunca lo entenderán*    
> *Este amor por la pelota me sobrepasó,*    
> *Porque me crie viviendo una pasión q jamás entenderán.*    
> *Hasta q el barbón me regale un aliento más,*    
> *Ahí estaré en una cancha*    
> *Y el día q tenga nietos, los llevare,*    
> *Como lleve a mis hijos, así no entiendan está pasión*    
> *¡¡Soy un jugador de barrio y lo seré hasta el día q me muera!!*    