# 👤 Francisco Luis Bernárdez

## 📖 Poema Para Recobrar

> *Si para recobrar lo recobrado*  
> *debí perder primero lo perdido,*  
> *sí para conseguir lo conseguido*  
> *tuve que soportar lo soportado,*  
> *sí para estar ahora enamorado*  
> *fue menester haber estado herido,*  
> *tengo por bien sufrido lo sufrido,*  
> *tengo por bien llorado lo llorado.*

> *Porque después de todo he comprobado*  
> *que no se goza bien de lo gozado*  
> *sino después de haberlo padecido.*

> *Porque después de todo he comprendido*  
> *por lo que el árbol tiene de florido*  
> *vive de lo que tiene sepultado.*
