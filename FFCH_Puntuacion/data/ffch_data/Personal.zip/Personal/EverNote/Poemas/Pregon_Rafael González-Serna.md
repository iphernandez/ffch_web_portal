# 👤 Rafael González-Serna

## 📖 Pregón (Hermandad del Gran Poder)

> *Que nadie marque mi camino entre los hombres*    
> *Que nadie diga cuando tengo que rezarte*    
> *&nbsp;&nbsp;&nbsp;&nbsp;o cuando debo hacer mis peticiones*    

> *No deseo que se burlen de tu imagen*    
> *Que si quieren renegarte, que renieguen*    
> *Si no quieren ni mirarte, que se aparten*    
> *Que no vengan a imponerme con sus leyes*    
> *&nbsp;&nbsp;&nbsp;&nbsp;cuando tengo que venir a suplicarte*    

> *Me enseñaste a poner la otra mejilla*    
> *&nbsp;&nbsp;&nbsp;&nbsp;y en mi perdón es donde encuentren fortaleza*    

> *Se equivocan si al pensar que aquí en Sevilla*    
> *&nbsp;&nbsp;&nbsp;&nbsp;dudaremos en salir en tu defensa*    

> *No propongo enfrentamientos ni guerrilla*    
> *Y no impongo mi creencia por la fuerza*    
> *Sólo hablo de rezar un Padre Nuestro*    
> *&nbsp;&nbsp;&nbsp;&nbsp;que se escuche en los confines de la tierra*    

> *Y ese día que me encuentre ante tus ojos,*    
> *&nbsp;&nbsp;&nbsp;&nbsp;de rodillas humillado en tu presencia*    
> *&nbsp;&nbsp;&nbsp;&nbsp;gran poder que perdones nuestras deudas*    

> *Si me pides que perdone yo perdono,*    
> *&nbsp;&nbsp;&nbsp;&nbsp;aunque  duela perdonar al que te ofenda.*    
