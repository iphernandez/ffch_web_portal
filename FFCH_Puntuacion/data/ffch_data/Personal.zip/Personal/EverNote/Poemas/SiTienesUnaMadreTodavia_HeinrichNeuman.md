# 👤 Heinrich Neuman

## 📖 Si tienes una Madre todavía

> *Si tienes una madre todavía,*    
> *&nbsp;da gracias al Señor que te ama tanto,*    
> *&nbsp;que no todo mortal contar podría,*    
> *&nbsp;dicha tan grande ni placer tan santo.*    

> *Si tienes una madre… sé tan bueno*    
> *&nbsp;que ha de cuidar tu amor su paz sabrosa,*    
> *&nbsp;pues la que un día te llevo en su seno*    
> *&nbsp;siguió sufriendo y se creyó dichosa.*    

> *Veló de noche y trabajó de día*    
> *&nbsp;leves las horas en su afán pasaban,*    
> *&nbsp;un cantar de sus labios te dormía,*    
> *&nbsp;y al despertar sus labios te besaban.*    

> *Enfermo y triste, te salvó su anhelo*    
> *&nbsp;que sólo el llanto por su bien querido*    
> *&nbsp;milagros supo arrebatar al cielo,*    
> *&nbsp;cuando ya el mundo te creyó perdido.*    

> *Ella puso en tu boca la dulzura*    
> *&nbsp;de la oración primera balbucida*    
> *&nbsp;y plegando tus manos en ternura,*    
> *&nbsp;te enseñaba la ciencia de la vida.*    

> *Si acaso sigues por la senda aquella*    
> *&nbsp;que va segura a tu feliz destino,*    
> *&nbsp;herencia santa de la madre es ella,*    
> *&nbsp;tu madre sola te enseñó el camino.*    

> *Mas si al cielo se fue… y en tus amores*    
> *&nbsp;ya no la harás feliz sobre la tierra,*    
> *&nbsp;deposita el recuerdo de tus flores*    
> *&nbsp;sobre la fría loza que la encierra.*    

> *Es tan santa la tumba de una madre,*    
> *&nbsp;que no hay al corazón lugar más santo,*    
> *&nbsp;cuando espina cruel tu alma taladre,*    
> *&nbsp;¡ve a derramar, allí, tu triste llanto!*    