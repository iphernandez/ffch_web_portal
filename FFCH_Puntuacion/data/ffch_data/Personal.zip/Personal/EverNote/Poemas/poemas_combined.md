# 👤 Alberto Córtez

## 📖 Qué suerte he tenido de nacer

> *Qué suerte he tenido de nacer,*    
> *para estrechar la mano de un amigo*    
> *y poder asistir como testigo*    
> *al milagro de cada amanecer.*    

> *Qué suerte he tenido de nacer,*    
> *para tener la opción de la balanza,*    
> *sopesar la derrota y la esperanza*    
> *con la gloria y el miedo de caer.*    

> *Qué suerte he tenido de nacer,*    
> *para entender que el honesto y el perverso*    
> *son dueños por igual del universo*    
> *aunque tengan distinto parecer.*    

> *Qué suerte he tenido de nacer,*    
> *para callar cuando habla el que más sabe,*    
> *aprender a escuchar, ésa es la clave,*    
> *si se tiene intenciones de saber.*    

> *Qué suerte he tenido de nacer,*    
> *y lo digo sin falsos triunfalismos,*    
> *la victoria total, la de uno mismo,*    
> *se concreta en el ser y en el no ser.*    

> *Qué suerte he tenido de nacer,*    
> *para cantarle a la gente y a la rosa*    
> *y al perro y al amor y a cualquier cosa*    
> *que pueda el sentimiento recoger.*    

> *Qué suerte he tenido de nacer,*    
> *para tener acceso a la fortuna*    
> *de ser río en lugar de ser laguna,*    
> *de ser lluvia en lugar de ver llover.*    

> *Qué suerte he tenido de nacer,*    
> *para comer a conciencia la manzana,*    
> *sin el miedo ancestral a la sotana*    
> *ni a la venganza final de Lucifer.*    

> *Pero sé, bien que sé...*    
> *que algún día también me moriré.*    
> *Si ahora vivo contento con mi suerte,*    
> *sabe Dios qué pensaré cuando mi muerte,*    
> *cuál será en la agonía mi balance, no lo sé,*    
> *nunca estuve en ese trance.*    

> *Pero sé, bien que sé...*    
> *que en mi viaje final escucharé*    
> *el ambiguo tañir de las campanas*    
> *saludando mi adiós, y otra mañana*    
> *y otra voz, como yo, con otro acento,*    
> *cantará a los cuatro vientos...*    
> *Qué suerte he tenido de nacer.*    

- Pasted from <http://www.albertocortez.com/poemas/home.asp?Id=89>

---

## 📖 El Vino

> *Sí señor... el vino puede sacar*    
> *cosas que el hombre se calla;*    
> *que deberían salir*    
> *cuando el hombre bebe agua.*    

> *Va buscando, pecho adentro,*    
> *por los silencios del alma*    
> *y les va poniendo voces*    
> *y los va haciendo palabras.*    

> *A veces saca una pena,*    
> *que por ser pena, es amarga;*    
> *sobre su palco de fuego,*    
> *la pone a bailar descalza.*    

> *Baila y bailando se crece,*    
> *hasta que el vino se acaba*    
> *y entonces, vuelve la pena*    
> *a ser silencio del alma.*    

> *El vino puede sacar*    
> *cosas que el hombre se calla.*    

> *Cosas que queman por dentro,*    
> *cosas que pudren el alma*    
> *de los que bajan los ojos,*    
> *de los que esconden la cara.*    

> *El vino entonces, libera*    
> *la valentía encerrada*    
> *y los disfraza de machos,*    
> *como por arte de magia...*    

> *Y entonces, son bravucones,*    
> *hasta que el vino se acaba*    
> *pues del matón al cobarde,*    
> *solo media, la resaca.*    

> *El vino puede sacar*    
> *cosas que el hombre se calla.*    

> *Cambia el prisma de las cosas*    
> *cuando más les hace falta*    
> *a los que llevan sus culpas*    
> *como una cruz a la espalda.*    

> *La puta se piensa pura,*    
> *como cuando era muchacha*    
> *y el cornudo regatea*    
> *la medida de sus astas.*    

> *Y todo tiene colores*    
> *de castidad, simulada,*    
> *pues siempre acaban el vino*    
> *los dos, en la misma cama.*    

> *El vino puede sacar*    
> *cosas que el hombre se calla.*    

> *Pero... ¡qué lindo es el vino!*    
> *El que se bebe en la casa*    
> *del que está limpio por dentro*    
> *y tiene brillando el alma.*    

> *Que nunca le tiembla el pulso,*    
> *cuando pulsa una guitarra.*    
> *Que no le falta un amigo*    
> *ni noches para gastarlas.*    


> *Que cuando tiene un pecado,*    
> *siempre se nota en su cara...*    
> *Que bebe el vino por vino*    
> *y bebe el agua, por agua.*    




# 👤 José Joaquín de Olmedo

## 📖 Alfabeto para un niño

> *AMOR de patria comprende*  
> *cuanto el hombre debe amar:*  
> *Su Dios, sus leyes, su hogar,*  
> *y el honor que los defiende.*  
 
> *BONDAD, el que la merece*  
>  *con ánimo siempre igual,*  
>  *ni se abate con el mal,*  
>  *ni en el bien se ensóbrese.*  

> *CANDOR en toda expresión,*  
> *callar lo más que pudieres;*  
> *muy cortés con las mujeres,*  
> *pero sin afectación.*  

> *DIOS es el sabio creador*  
> *que conserva y ama al hombre,*  
> *sea cual fuere su nombre,*  
> *condición, secta y color.*  

> *ESTUDIO y aplicación*  
> *forman a la juventud,*  
> *y emulación de virtud*  
> *sin envidia ni ambición.*  

> *FRANQUEZA, nunca indecencia,*  
> *usa en la conversación;*  
> *disimulo y no ficción;*  
> *libertad, nunca licencia.*  

> *GRATITUD siempre al favor*  
> *es un deber justo y grato;*  
> *y es por eso el hombre ingrato*  
> *es un monstruo que da horror.*  

> *HONOR es en sumo grado*  
> *el alma del ciudadano:*  
> *sin honor es miembro vano,*  
> *o pernicioso al Estado.*  

> *IRA hace al hombre un tirano*  
> *de inferiores y de iguales:*  
> *la ira es propia de animales,*  
> *porque no es afecto humano.*  

> *JUEGO es una diversión honesto, si es moderado;*  
> *pero si es inmoderado*  
> *causa nuestra perdición.*  

> *LIBERTAD ¡oh dulce nombre!*  
> *hermoso y celeste don:*  
> *tú eres la misma razón,*  
> *tú eres el alma del hombre.*  

> *MORAL, la sana moral*  
> *consiste en amarse bien,*  
> *en hacer a todos bien,*  
> *y en no hacer a nadie mal.*  

> *NATURALEZA sagaz*  
> *llena y rige al universo:*  
> *todo está bien; el perverso*  
> *solamente está de más.*  

> *ORO es un bien apreciable*  
> *para el cómodo sustento;*  
> *pero es el mayor tormento*  
> *la sed de oro insaciable.*  

> *PEREZA es enfermedad*  
> *tan mala como la muerte;*  
> *así no cabe el inerte*  
> *en ninguna sociedad.*  

> *QUIJOTERÍA es un vicio*  
> *que causa risa y desprecio,*  
> *pues es un quijote necio*  
> *corre aventuras el juicio.*  

> *RESPETO a los superiores,*  
> *respeto y amor al padre,*  
> *amor, ternura a la madre,*  
> *reverencia a los mayores.*  

> *SOCIEDAD es el estado*  
> *en que con otro vivieres,*  
> *y serás social si fueres*  
> *justo, modesto y aseado.*  

> *TIRANÍA y opresión*  
> *suenan y expresan lo mismo:*  
> *para salir de este abismo*  
> *es honrosa toda acción.*  

> *VENGANZA, nunca jamás:*  
> *nunca, nunca odio o rencor;*  
> *porque no hay placer mayor*  
> *como amar y perdonar.*  

> *YO debo ser el primero*  
> *para mi conservación;*  
> *mas por buena educación*  
> *en sociedad el postrero.*  

> *ZELO en cumplir su deber*  
> *en cualquier condición,*  
> *será la única ambición*  
> *que un niño debe tener.*  

> *Estas reglas niño amado,*  
> *te harán un niño gracioso,*  
> *un joven pundonoroso,*  
> *un hombre bueno y honrado*  
> *y un anciano respetado*  
> *que a sus iguales auxilia,*  
> *sus diferencias concilia,*  
> *con bondad, no con rigor,*  
> *y muere siendo el honor*  
> *de su patria y su familia.*  

- **Obtenido de "http://es.wikisource.org/wiki/Alfabeto_para_un_ni%C3%B1o"**  

  



# 👤 Pedro B. Palacios - Almafuerte

## 📖 ¡AVANTI!

> *Si te postran diez veces, te levantas*    
> *otras diez, otras cien, otras quinientas:*    
> *no han de ser tus caídas tan violentas*    
> *ni tampoco, por ley, han de ser tantas.*    
> *Con el hambre genial con que las plantas*    
> *asimilan el humus avarientas,*    
> *deglutiendo el rencor de las afrentas*    
> *se formaron los santos y las santas.*    
> *Obsesión casi asnal, para ser fuerte,*    
> *nada más necesita la criatura,*    
> *y en cualquier infeliz se me figura*    
> *que se mellan los garfios de la suerte . . .*    
> *¡Todos los incurables tienen cura*    
> *cinco segundos antes de su muerte!*    
   
## 📖 ¡PIU AVANTI!
  
> *No te des por vencido, ni aun vencido,*    
> *no te sientas esclavo, ni aun esclavo;*    
> *trémulo de pavor, piénsate bravo,*    
> *y arremete feroz, ya mal herido.*    
> *Ten el tesón del clavo enmohecido*    
> *que ya viejo y ruin, vuelve a ser clavo;*    
> *no la cobarde estupidez del pavo*    
> *que amaina su plumaje al primer ruido.*    
> *Procede como Dios que nunca llora;*    
> *o como Lucifer, que nunca reza;*    
> *o como el robledal, cuya grandeza*    
> *necesita del agua y no la implora...*    
> *Que muerda y vocifere vengadora,*    
> *ya rodando en el polvo, tu cabeza!*    

## 📖 ¡MOLTO PIU AVANTI!

> *Los que vierten sus lágrimas amantes*    
> *sobre las penas que no son sus penas;*    
> *los que olvidan el son de sus cadenas*    
> *para limar las de los otros antes;*    
> *Los que van por el mundo delirantes*    
> *repartiendo su amor a manos llenas,*    
> *caen, bajo el peso de sus obras buenas,*    
> *sucios, enfermos, trágicos... ¡sobrantes!*    
> *¡Ah! ¡Nunca quieras remediar entuertos!*    
> *¡nunca sigas impulsos compasivos!*    
> *¡ten los garfios del Odio siempre activos*    
> *los ojos del juez siempre despiertos!*    
> *¡Y al echarte en la caja de los muertos,*    
> *menosprecia los llantos de los vivos!*    

## 📖 ¡MOLTO PIU AVANTI ANCORA!

> *El mundo miserable es un estrado*    
> *donde todo es estólido y fingido,*    
> *donde cada anfitrión guarda escondido*    
> *su verdadero ser, tras el tocado:*    
> *No digas tu verdad ni al más amado,*    
> *no demuestres temor ni al más temido,*    
> *no creas que jamás te hayan querido*    
> *por más besos de amor que te hayan dado.*    
> *Mira como la nieve se deslíe*    
> *sin que apostrofe al sol su labio yerto,*    
> *cómo ansía las nubes el desierto*    
> *sin que a ninguno su ansiedad confíe...*    
> *¡Trema como el infierno, pero ríe!*    
> *¡Vive la vida plena, pero muerto!*    

## 📖 ¡MOLTISSIMO PIU AVANTI ANCORA!

> *Si en vez de las estúpidas panteras*    
> *y los férreos estúpidos leones,*    
> *encerrasen dos flacos mocetones*    
> *en esa frágil cárcel de las fieras,*    
> *No habrían de yacer noches enteras*    
> *en el blando pajar de sus colchones,*    
> *sin esperanzas ya, sin reacciones*    
> *lo mismo que dos plácidos horteras;*    
> *Cual Napoleones pensativos, graves,*    
> *no como el tigre sanguinario y maula,*    
> *escrutarían palmo a palmo su aula,*    
> *buscando las rendijas, no las llaves...*    
> *¡Seas el que tú seas, ya lo sabes:*    
> *a escrutar las rendijas de tu jaula!*    

## 📖 VERA VIOLETA

> *En pos de su nivel se lanza el río*    
> *por el gran desnivel de los breñales;*    
> *el aire es vendaval, y hay vendavales*    
> *por la ley del no fin, del no vacío;*    
> *la más hermosa espiga del estío*    
> *ni sueña con el pan en los trigales;*    
> *el más dulce panal de los panales*    
> *no declaró jamás: yo no soy mío.*    
> *Y el sol, el padre sol, el raudo foco*    
> *que fomenta la vida en la Natura,*    
> *por calentar los polos no se apura,*    
> *ni se desvía un ápice tampoco:*    
> *¡Todo lo alcanzarás, solemne loco,*    
> *siempre que lo permita tu estatura!*    

## 📖 LA YAPA

> *Como una sola estrella no es el cielo,*    
> *ni una gota que salta, el Océano,*    
> *ni una falange rígida, la mano,*    
> *ni una brizna de paja, el santo suelo:*    
> *tu gimnasia de cárcel, no es el vuelo,*    
> *el sublime tramonto soberano,*    
> *ni nunca podrá ser anhelo humano*    
> *tu miserable personal anhelo.*    
> *¿Qué saben de lo eterno las esferas;*    
> *de las borrascas de la mar, la gota;*    
> *de puñetazos, la falange rota;*    
> *de harina y pan, la paja de las eras?...*    
> *¡Detente, por piedad, pluma no quieras*    
> *que abandone sus armas el idiota!*    




# 👤 Gabriel García Márquez (*)

## 📖 El Juramento

> *Y entonces resolví asistir al estadio. Como era un encuentro más sonado que todos los anteriores, tuve que irme temprano. Confieso que nunca en mi vida he llegado tan temprano a ninguna parte y que de ninguna tampoco he salido tan agotado. Alfonso y Germán no tomaron nunca la iniciativa de convertirme a esa religión dominical del fútbol, con todo y que ellos debieron sospechar que alguna vez me iba a convertir en ese energúmeno, limpio de cualquier barniz que pueda ser considerado como el último rastro de civilización, que fui ayer en las graderías del municipal. El primer instante de lucidez en que caí en la cuenta de que estaba convertido en un hincha intempestivo, fue cuando advertí que durante toda mi vida había tenido algo de que muchas veces me había ufanado y que ayer me estorbaba de una manera inaceptable: el sentido del ridículo. Ahora me explico por qué esos caballeros habitualmente tan almidonados, se sienten como un calamar en su tinta cuando se colocan, con todas las de la ley, su gorrita a varios colores.*    

> *Es que con ese solo gesto, quedan automáticamente convertidos en otras personas, como si la gorrita no fuera sino el uniforme de una nueva personalidad. No sé si mi matrícula de hincha esté todavía demasiado fresca para permitirme ciertas observaciones personales acerca del partido de ayer, pero como ya hemos quedado de acuerdo en que una de las condiciones esenciales del hinchaje es la pérdida absoluta y aceptada del sentido del ridículo, voy a decir lo que vi –o lo que creí ver ayer tarde– para darme el lujo de empezar bien temprano a meter esas patas deportivas que bien guardadas me tenía. En primer término, me pareció que el Junior dominó a Millonarios desde el primer momento. Si la línea blanca que divide la cancha en dos mitades significa algo, mi afirmación anterior es cierta, puesto que muy pocas veces pudo estar la bola, en el primer tiempo, dentro de la mitad correspondiente a la portería del Junior. (¿Qué tal va mi debut como comentarista de fútbol?). “No creo haber perdido nada con este irrevocable ingreso que hoy hago –públicamente– a la santa hermandad de los hinchas”.*    

> *Por otra parte, si los jugadores del Junior no hubieran sido ciertamente jugadores sino escritores, me parece que el maestro Heleno habría sido un extraordinario autor de novelas policíacas. Su sentido del cálculo, sus reposados movimientos de investigador y finalmente sus desenlaces rápidos y sorpresivos le otorgan suficientes méritos para ser el creador de un nuevo detective para la novelística de policía.*    
  
> *Haroldo, por su parte, habría sido una especie de Marcelino Menéndez y Pelayo, con esa facilidad que tiene el brasileño para estar en todas partes a la vez y en todas ellas trabajando, atendiendo simultáneamente a once señores, como si de lo que se tratara no fuera de colocar un gol sino de escribir todos los mamotretos que don Marcelino escribiera. Berascochea habría sido, ni más ni menos, un autor fecundo, pero así hubiera escrito setecientos tomos, todos ellos habrían sido acerca de la importancia de las cabezas de alfiler. Y qué gran crítico de artes habría sido Dos Santos –que ayer se portó como cuatro– cortándole el paso a todos los escribidorcillos que pretendieran llegar, así fuera con los mayores esfuerzos, a la portería de la inmortalidad. De Latour habría escrito versos. Inspirados poemas de largometraje, cosa que no podría decirse de Ary. Porque de Ary no puede decirse nada, ya que sus compañeros del Junior no le dieron oportunidad de demostrar al menos sus más modestas condiciones literarias.*    

> *Y esto por no entrar con los Millonarios, cuyo gran Di Stéfano, si de algo sabe, es de retórica. No creo haber perdido nada con este irrevocable ingreso que hoy hago –públicamente– a la santa hermandad de los hinchas. Lo único que deseo, ahora, es convertir a alguien. Y creo que va a ser a mi distinguido amigo, el doctor Adalberto Reyes, a quien voy a convidar a las graderías del Municipal en el primer partido de la segunda vuelta, con el propósito de que no siga siendo –desde el punto de vista deportivo– la oveja descarriada.*          



# 👤 Rudyard Kipling

## 📖 If...
 
> *If you can keep your head when all around you
> *Are losing theirs and blaming it on you;

> *If you can trust yourself when all men doubt you,
> *But make allowance for their doubting too;

> *If you can wait and not be tired by waiting,
> *Or, being lied about, don't deal in lies,
> *Or, being hated, don't give way to hating,
> *And yet don't look too good, nor talk too wise;

> *If you can dream—and not make dreams your master;
> *If you can think—and not make thoughts your aim;
> *If you can meet with triumph and disaster
> *And treat those two imposters just the same;
> *If you can bear to hear the truth you've spoken
> *Twisted by knaves to make a trap for fools,
> *Or watch the things you gave your life to broken,
> *And stoop and build 'em up with wornout tools;

> *If you can make one heap of all your winnings
> *And risk it on one turn of pitch-and-toss,
> *And lose, and start again at your beginnings
> *And never breathe a word about your loss;
> *If you can force your heart and nerve and sinew
> *To serve your turn long after they are gone,
> *And so hold on when there is nothing in you
> *Except the Will which says to them: "Hold on";

> *If you can talk with crowds and keep your virtue,
> *Or walk with kings—nor lose the common touch;
> *If neither foes nor loving friends can hurt you;
> *If all men count with you, but none too much;
> *If you can fill the unforgiving minute
> *With sixty seconds' worth of distance run

> *Yours is the Earth and everything that's in it,

> *And—which is more—you'll be a Man my son!

## 📖 Si...

> *Si puedes mantener en su lugar tu cabeza cuando todos a tu alrededor,
> *han perdido la suya y te culpan de ello.

> *Si crees en ti mismo cuando todo el mundo duda de ti,
> *pero también dejas lugar a sus dudas.

> *Si puedes esperar y no cansarte de la espera;
> *o si, siendo engañado, no respondes con engaños,
> *o si, siendo odiado, no te domina el odio
> *Y aún así no pareces demasiado bueno o demasiado sabio.

> *Si puedes soñar y no hacer de los sueños tu amo;
> *Si puedes pensar y no hacer de tus pensamientos tu único objetivo;
> *Si puedes conocer al triunfo y la derrota,
> *y tratar de la misma manera a esos dos impostores.
> *Si puedes soportar oír toda la verdad que has dicho,
> *tergiversada por malhechores para engañar a los necios.
> *O ver cómo se rompe todo lo que has creado en tu vida,
> *y agacharte para reconstruírlo con herramientas maltrechas.

> *Si puedes amontonar todo lo que has ganado
> *y arriesgarlo todo a un sólo lanzamiento ;
> *y perderlo, y empezar de nuevo desde el principio
> *y no decir ni una palabra sobre tu pérdida.
> *Si puedes forzar tu corazón y tus nervios y tus tendones,
> *para seguir adelante mucho después de haberlos perdido,
> *y resistir cuando no haya nada en ti
> *salvo la voluntad que te dice: "Resiste!".

> *Si puedes hablar a las masas y conservar tu virtud.
> *o caminar junto a reyes, y no distanciarte de los demás.
> *Si ni amigos ni enemigos pueden herirte.
> *Si todos cuentan contigo, pero ninguno demasiado.
> *Si puedes llenar el inexorable minuto,
> *con sesenta segundos que valieron la pena recorrer...

> *Todo lo que hay sobre La Tierra será tuyo,

> *y lo que es más: serás un hombre, hijo mío.

- **Pasted from <http://es.wikipedia.org/wiki/Si..._(Kipling)>**




# 👤 Joan Manuel Serrat

## 📖 La Saeta

> *Dijo una voz popular:*    
> *"¿Quién me presta una escalera para subir al madero*    
> *Para quitarle los clavos a Jesús, el Nazareno?"*    
> *Oh, la saeta al cantar*    
> *Al Cristo de los gitanos*    
> *Siempre con sangre en las manos*    
> *Siempre por desenclavar*    
> *Cantar del pueblo andaluz*    
> *Que todas las primaveras*    
> *Anda pidiendo escaleras*    
> *Para subir a la cruz*    
> *Cantar de la tierra mía*    
> *Que echa flores*    
> *Al Jesús de la agonía*    
> *Y es la fe de mis mayores*    
> *Oh, no eres tú mi cantar*    
> *No puedo cantar, ni quiero*    
> *A este Jesús del madero*    
> *Sino al que anduvo en la mar*    
> *Oh, no eres tú mi cantar*    
> *No puedo cantar, ni quiero*    
> *A ese Jesús del madero*    
> *Sino al que anduvo en la mar*    
> *Oh, no eres tú mi cantar*    
> *No puedo cantar, ni quiero*    
> *A ese Jesús del madero*    
> *Sino al que anduvo en la mar*    
> *Oh, no eres tú mi cantar*    



# 👤 Mario Benedetti

## 📖 No Te rindas

> *No te rindas, aun estas a tiempo*   
> *de alcanzar y comenzar de nuevo,*   
> *aceptar tus sombras, enterrar tus miedos,*   
> *liberar el lastre, retomar el vuelo.*   

> *No te rindas que la vida es eso,*   
> *continuar el viaje,*   
> *perseguir tus sueños,*   
> *destrabar el tiempo,*   
> *correr los escombros y destapar el cielo.*   

> *No te rindas, por favor no cedas,*   
> *aunque el frio queme,*   
> *aunque el miedo muerda,*   
> *aunque el sol se esconda y se calle el viento,*   
> *aun hay fuego en tu alma,*   
> *aun hay vida en tus sueños,*   
> *porque la vida es tuya y tuyo tambien el deseo,*   
> *porque lo has querido y porque te quiero.*   

> *Porque existe el vino y el amor, es cierto,*   
> *porque no hay heridas que no cure el tiempo,*   
> *abrir las puertas quitar los cerrojos,*   
> *abandonar las murallas que te protegieron.*   

> *Vivir la vida y aceptar el reto,*   
> *recuperar la risa, ensayar el canto,*   
> *bajar la guardia y extender las manos,*   
> *desplegar las alas e intentar de nuevo,*   
> *celebrar la vida y retomar los cielos,*   

> *No te rindas por favor no cedas,*   
> *aunque el frio queme,*   
> *aunque el miedo muerda,*   
> *aunque el sol se ponga y se calle el viento,*   
> *aun hay fuego en tu alma,*   
> *aun hay vida en tus sueños,*   
> *porque cada dia es un comienzo,*   
> *porque esta es la hora y el mejor momento,*   
> *porque no estas sola,*   
> *porque yo te quiero.*   



# 👤 Anonimo

## 📖 Pasión del fútbol

> *¿Porque juegas?  Me pregunto mi hijo*    
> *¿para qué vas, si ya no puedes jugar?*    
> *Para que pierdes tu tiempo*    
> *Si ya no te van a poner!!!!!!  Aseguro mi gordito*    
> *quédate conmigo a ver televisión mejor!!!*    

> *Quiero jugar hasta el día en que me muera,*    
> *Quiero jugar porque me crie así desde niño,*    
> *!!El fútbol lo era todo para mi generación!! ,*    

> *Jugare hasta el día que tenga aliento,*    
> *Quiero jugar un rato más, así sean pocos campeonatos,*    
> *Así sean pocos minutos, así sea viendo jugar a mis amigos*    
> *Estaré en una cancha de futbol, de futbolito, de mini fútbol*    
> *¡¡¡Nunca será para mi perder el tiempo estar en una cancha!!!*    
> *¡¡¡Jamás!!!*    

> *Estaré así sea para que me den 5 minutos o 1 en una cancha*    
> *Estaré ahí y me molestare, renegare, jodere,*    
> *Pero ahí estaré esperando mi oportunidad,*    
> *La oportunidad de sentirme vivo otra vez,*    
> *Dándole a un balón*    
> *Si no puedo jugar, estaré para alentar,*    
> *Para dirigir, para joder, para gritar*    
> *Mis hijos nunca entenderán esto,*    
> *¡¡¡No son mi generación!!!*    

> *Así me gane problemas con mis hijos,*    
> *Así me gane problemas con mi mujer*    
> *Así me gane problemas con mi vieja*    
> *Así me gane problemas con el trabajo*    
> *Saldré a distraerme*    
> *Saldré a jugar o a ver*    
> *Saldré con cualquier excusa, pero saldré*    
> *Que van a saber si para nosotros de niños*    
> *El regalo soñado era un balón de futbol,*    
> *Donde lo mejor del día era juntarte con los patas*    
> *Para darle al balón, donde esperabas que empezará*    
> *¡¡¡El campeonato del barrio para poder jugar, eso era todo!!!*    
> *Antes era difícil jugar en la liga*    
> *Era bravo representar a tu barrio*    
> *Y era más bravo ser "jale"*    
> *Mis hijos nunca lo entenderán*    
> *Este amor por la pelota me sobrepasó,*    
> *Porque me crie viviendo una pasión q jamás entenderán.*    
> *Hasta q el barbón me regale un aliento más,*    
> *Ahí estaré en una cancha*    
> *Y el día q tenga nietos, los llevare,*    
> *Como lleve a mis hijos, así no entiendan está pasión*    
> *¡¡Soy un jugador de barrio y lo seré hasta el día q me muera!!*    



# 👤 Francisco Luis Bernárdez

## 📖 Poema Para Recobrar

> *Si para recobrar lo recobrado*  
> *debí perder primero lo perdido,*  
> *sí para conseguir lo conseguido*  
> *tuve que soportar lo soportado,*  
> *sí para estar ahora enamorado*  
> *fue menester haber estado herido,*  
> *tengo por bien sufrido lo sufrido,*  
> *tengo por bien llorado lo llorado.*

> *Porque después de todo he comprobado*  
> *que no se goza bien de lo gozado*  
> *sino después de haberlo padecido.*

> *Porque después de todo he comprendido*  
> *por lo que el árbol tiene de florido*  
> *vive de lo que tiene sepultado.*




# 👤 Rafael González-Serna

## 📖 Pregón (Hermandad del Gran Poder)

> *Que nadie marque mi camino entre los hombres*    
> *Que nadie diga cuando tengo que rezarte*    
> *&nbsp;&nbsp;&nbsp;&nbsp;o cuando debo hacer mis peticiones*    

> *No deseo que se burlen de tu imagen*    
> *Que si quieren renegarte, que renieguen*    
> *Si no quieren ni mirarte, que se aparten*    
> *Que no vengan a imponerme con sus leyes*    
> *&nbsp;&nbsp;&nbsp;&nbsp;cuando tengo que venir a suplicarte*    

> *Me enseñaste a poner la otra mejilla*    
> *&nbsp;&nbsp;&nbsp;&nbsp;y en mi perdón es donde encuentren fortaleza*    

> *Se equivocan si al pensar que aquí en Sevilla*    
> *&nbsp;&nbsp;&nbsp;&nbsp;dudaremos en salir en tu defensa*    

> *No propongo enfrentamientos ni guerrilla*    
> *Y no impongo mi creencia por la fuerza*    
> *Sólo hablo de rezar un Padre Nuestro*    
> *&nbsp;&nbsp;&nbsp;&nbsp;que se escuche en los confines de la tierra*    

> *Y ese día que me encuentre ante tus ojos,*    
> *&nbsp;&nbsp;&nbsp;&nbsp;de rodillas humillado en tu presencia*    
> *&nbsp;&nbsp;&nbsp;&nbsp;gran poder que perdones nuestras deudas*    

> *Si me pides que perdone yo perdono,*    
> *&nbsp;&nbsp;&nbsp;&nbsp;aunque  duela perdonar al que te ofenda.*    




# 👤 Heinrich Neuman

## 📖 Si tienes una Madre todavía

> *Si tienes una madre todavía,*    
> *&nbsp;da gracias al Señor que te ama tanto,*    
> *&nbsp;que no todo mortal contar podría,*    
> *&nbsp;dicha tan grande ni placer tan santo.*    

> *Si tienes una madre… sé tan bueno*    
> *&nbsp;que ha de cuidar tu amor su paz sabrosa,*    
> *&nbsp;pues la que un día te llevo en su seno*    
> *&nbsp;siguió sufriendo y se creyó dichosa.*    

> *Veló de noche y trabajó de día*    
> *&nbsp;leves las horas en su afán pasaban,*    
> *&nbsp;un cantar de sus labios te dormía,*    
> *&nbsp;y al despertar sus labios te besaban.*    

> *Enfermo y triste, te salvó su anhelo*    
> *&nbsp;que sólo el llanto por su bien querido*    
> *&nbsp;milagros supo arrebatar al cielo,*    
> *&nbsp;cuando ya el mundo te creyó perdido.*    

> *Ella puso en tu boca la dulzura*    
> *&nbsp;de la oración primera balbucida*    
> *&nbsp;y plegando tus manos en ternura,*    
> *&nbsp;te enseñaba la ciencia de la vida.*    

> *Si acaso sigues por la senda aquella*    
> *&nbsp;que va segura a tu feliz destino,*    
> *&nbsp;herencia santa de la madre es ella,*    
> *&nbsp;tu madre sola te enseñó el camino.*    

> *Mas si al cielo se fue… y en tus amores*    
> *&nbsp;ya no la harás feliz sobre la tierra,*    
> *&nbsp;deposita el recuerdo de tus flores*    
> *&nbsp;sobre la fría loza que la encierra.*    

> *Es tan santa la tumba de una madre,*    
> *&nbsp;que no hay al corazón lugar más santo,*    
> *&nbsp;cuando espina cruel tu alma taladre,*    
> *&nbsp;¡ve a derramar, allí, tu triste llanto!*    



