# ✝️ Papa Francisco

---

## 🌟 Citas

> *"Dios es nuestro papá, que nos ama aun cuando nos equivocamos. Jesús es nuestro más grande abogado defensor."*

> *"La dignidad no es la que da el poder, el dinero, la cultura, no. La dignidad nos la da el trabajo y siempre un trabajo digno."*

> *"Que callen las armas. Frente a la violencia y los atropellos renuevo con fuerza mi llamamiento a la paz en Siria."*

> *"Que se garantice protección jurídica al embrión tutelando a todo ser humano desde el primer momento de su existencia."*

> *"La Semana Santa significa salir de nosotros mismos para ir a la periferia al encuentro de los más alejados."*

---

— **Papa Francisco**
``