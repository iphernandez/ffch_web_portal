# 📖 Quotes

---

## 🌟 Preferida

> *El pasado muere, El presente vive, El recuerdo queda y La vida sigue*  
— **Anónimo**

---

## 🧭 Definition of Culture

While corporate culture is always evolving over time with the addition of new employees and technologies, the existing artifacts and principles define the core of what the organization is.  
These artifacts and principles are pieces that typically include a set of shared values, attitudes, goals, beliefs, philosophies, rituals, policies, practices, rules of conduct, traditions, and history.  
These are the things that make up a culture and define a company.

---

## 🧠 Bertolt Brecht

> *Hay hombres que luchan un día y son buenos.*  
> *Hay otros que luchan un año y son mejores.*  
> *Hay otros que luchan muchos años y son muy buenos.*  
> *Pero hay quienes luchan toda la vida, esos son imprescindibles.*

---

## ☀️ Jose María Cano

> *Y aunque te haga calor*  
> *vete igual por el sol*  
> *que la sombra esta bien*  
> *para’ los blandos de piel*  
> *que les pique el sudor*

> *Si le da por llover*  
> *no te de por correr*  
> *que mojarse es crecer*  
> *y corriendo entre charcos*  
> *te puedes caer*

---

## ☀️ Diomedes Díaz

> *Que si te inspira ser zapatero*  
> *sólo quiero que seas el mejor*  
> *por que de nada sirve el doctor*  
> *si es el ejemplo malo del pueblo*

---

## 🧠 Theodore Roosevelt

> *“It is not the critic who counts; not the man who points out how the strong man stumbles, or where the doer of deeds could have done them better. The credit belongs to the man who is actually in the arena, whose face is marred by dust and sweat and blood; who strives valiantly; who errs, who comes short again and again, because there is no effort without error and shortcoming; but who does actually strive to do the deeds; who knows great enthusiasms, the great devotions; who spends himself in a worthy cause; who at the best knows in the end the triumph of high achievement, and who at the worst, if he fails, at least fails while daring greatly, so that his place shall never be with those cold and timid souls who neither know victory nor defeat.”
