# 🎬 Quotes & Movies

---

## 🌟 Favorita

> *El pasado muere, El presente vive, El recuerdo queda y La vida sigue*  
— **Anónimo**

---

## 🎭 V for Vendetta

> *"There's no certainty, only opportunity."*

> *"This may be the most important moment of your life. Commit to it."*

> *"People should not be afraid of their governments. Governments should be afraid of their people."*

> *".... artists use lies to tell the truth, while politicians use them to cover the truth up."*

> *"There are no coincidences.... only the illusion of coincidence."*

> *"I'd only told them the truth. Was that so selfish? Our integrity sells for so little, but it's all that we really have. It is the very last inch of us, but within that inch, we are free."*

> *"What I hope most of all is that you understand what I mean when I tell you that though I do not know you and even though I may never meet you, laugh with you, cry with you, or kiss you, I love you. With all my heart, I love you."*

> *"One thing is true of all governments – their most reliable records are tax records."*

> *"What'cha gonna do, uh? We've swept this place, you've got nothing. Nothing but your bloody knives and your fancy karate gimmicks, we have guns."*

> *"No, what you have are bullets, and the hope that when your guns are empty, I'm no longer standing, because if I am... you'll all be dead before you've reloaded."*

— **V**

---

## 📚 J. R. R. Tolkien

> *"All that is gold does not glitter, not all those who wander are lost; The old that is strong does not wither, Deep roots are not reached by frost."*

> *"I wish none of this had happened." ......  
"So do all who live to see such times, but that is not for them to decide. All we have to decide is what to do with the time that is given to us."*

> *"I don't know half of you half as well as I should like, and I like less than half of you half as well as you deserve."*

— **J. R. R. Tolkien**

---

## 🧠 Reflexiones

> *Lo importante no es el precio, sino el valor de las cosas.*  
— **Facundo Cabral**

> *Hay que desconfiar de los GENIOS porque a veces se hacen los muertos.*  
— **Ernesto Sabato**

---

## 🌍 Otros

> *Children are the living messages we send to a time we shall not see.*  
— *Attributed to Neil Postman*