# ✝️ Papa Francisco

---

## 🌟 Citas

> *"Dios es nuestro papá, que nos ama aun cuando nos equivocamos. Jesús es nuestro más grande abogado defensor."*

> *"La dignidad no es la que da el poder, el dinero, la cultura, no. La dignidad nos la da el trabajo y siempre un trabajo digno."*

> *"Que callen las armas. Frente a la violencia y los atropellos renuevo con fuerza mi llamamiento a la paz en Siria."*

> *"Que se garantice protección jurídica al embrión tutelando a todo ser humano desde el primer momento de su existencia."*

> *"La Semana Santa significa salir de nosotros mismos para ir a la periferia al encuentro de los más alejados."*

---

— **Papa Francisco**
``



# 📖 Quotes

---

## 🌟 Preferida

> *El pasado muere, El presente vive, El recuerdo queda y La vida sigue*  
— **Anónimo**

---

## 🧭 Definition of Culture

While corporate culture is always evolving over time with the addition of new employees and technologies, the existing artifacts and principles define the core of what the organization is.  
These artifacts and principles are pieces that typically include a set of shared values, attitudes, goals, beliefs, philosophies, rituals, policies, practices, rules of conduct, traditions, and history.  
These are the things that make up a culture and define a company.

---

## 🧠 Bertolt Brecht

> *Hay hombres que luchan un día y son buenos.*  
> *Hay otros que luchan un año y son mejores.*  
> *Hay otros que luchan muchos años y son muy buenos.*  
> *Pero hay quienes luchan toda la vida, esos son imprescindibles.*

---

## ☀️ Jose María Cano

> *Y aunque te haga calor*  
> *vete igual por el sol*  
> *que la sombra esta bien*  
> *para’ los blandos de piel*  
> *que les pique el sudor*

> *Si le da por llover*  
> *no te de por correr*  
> *que mojarse es crecer*  
> *y corriendo entre charcos*  
> *te puedes caer*

---

## ☀️ Diomedes Díaz

> *Que si te inspira ser zapatero*  
> *sólo quiero que seas el mejor*  
> *por que de nada sirve el doctor*  
> *si es el ejemplo malo del pueblo*

---

## 🧠 Theodore Roosevelt

> *“It is not the critic who counts; not the man who points out how the strong man stumbles, or where the doer of deeds could have done them better. The credit belongs to the man who is actually in the arena, whose face is marred by dust and sweat and blood; who strives valiantly; who errs, who comes short again and again, because there is no effort without error and shortcoming; but who does actually strive to do the deeds; who knows great enthusiasms, the great devotions; who spends himself in a worthy cause; who at the best knows in the end the triumph of high achievement, and who at the worst, if he fails, at least fails while daring greatly, so that his place shall never be with those cold and timid souls who neither know victory nor defeat.”




# 🎬 Quotes & Movies

---

## 🌟 Favorita

> *El pasado muere, El presente vive, El recuerdo queda y La vida sigue*  
— **Anónimo**

---

## 🎭 V for Vendetta

> *"There's no certainty, only opportunity."*

> *"This may be the most important moment of your life. Commit to it."*

> *"People should not be afraid of their governments. Governments should be afraid of their people."*

> *".... artists use lies to tell the truth, while politicians use them to cover the truth up."*

> *"There are no coincidences.... only the illusion of coincidence."*

> *"I'd only told them the truth. Was that so selfish? Our integrity sells for so little, but it's all that we really have. It is the very last inch of us, but within that inch, we are free."*

> *"What I hope most of all is that you understand what I mean when I tell you that though I do not know you and even though I may never meet you, laugh with you, cry with you, or kiss you, I love you. With all my heart, I love you."*

> *"One thing is true of all governments – their most reliable records are tax records."*

> *"What'cha gonna do, uh? We've swept this place, you've got nothing. Nothing but your bloody knives and your fancy karate gimmicks, we have guns."*

> *"No, what you have are bullets, and the hope that when your guns are empty, I'm no longer standing, because if I am... you'll all be dead before you've reloaded."*

— **V**

---

## 📚 J. R. R. Tolkien

> *"All that is gold does not glitter, not all those who wander are lost; The old that is strong does not wither, Deep roots are not reached by frost."*

> *"I wish none of this had happened." ......  
"So do all who live to see such times, but that is not for them to decide. All we have to decide is what to do with the time that is given to us."*

> *"I don't know half of you half as well as I should like, and I like less than half of you half as well as you deserve."*

— **J. R. R. Tolkien**

---

## 🧠 Reflexiones

> *Lo importante no es el precio, sino el valor de las cosas.*  
— **Facundo Cabral**

> *Hay que desconfiar de los GENIOS porque a veces se hacen los muertos.*  
— **Ernesto Sabato**

---

## 🌍 Otros

> *Children are the living messages we send to a time we shall not see.*  
— *Attributed to Neil Postman*



