# 🎂 🍊 Pastel de Naranja

Ingredientes

- 2.5 tazas de jugo de naranja
- 6 huevos
- 1 cucharada de polvo de hornear
- 2.5 tazas de harina
- 2 paquetes de mantequilla
- 1.5 tazas de azucar

Preparacion

Batir los huevos con la mantequilla y el azucar hasta que queden bien batidos y luego poner el harina y el polvo de hornear, seguir batiendo. Poner el jugo de naranja. Seguir batiendo.Tener listo el molde. Poner la masa en le molde y luego al horno a (375 grados) por 40 min.

---

# 🎂 🌰 Pastel de Nuez

Ingredientes:

- 1 taza Nueses
- 1 taza pasas
- 6 huevos
- 2 cucharadas de esencia de vainilla
- 1 cucharada de polvo de hornear
- 2.5 tazas de harina
- 2 paquetes de mantequilla
- 1.5 tazas de azucar
- 2 tazas de leche

Preparacion:

Batir los huevos con la mantequilla y el azucar hasta que queden bien batidos y luego poner el harina, la vainilla y el polvo de hornear, seguir batiendo. Poner las nueces, pasas y 1.5 tazas de leche. Seguir batiendo.Tener listo el molde. Poner la masa en le molde y luego al horno a (375 grados) por 40 min.


------------------
Check out this recipe that I found on Allrecipes.com via GoogleTV! http://allrecipes.com/Recipe/Antipasto-Squares/Detail.aspx