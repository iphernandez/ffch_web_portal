# 1. Define folder and destination paths
$SourceFolder = "C:\Users\iphernan\Downloads\Personal\EverNote\Quotes"
$OutputFile   = "C:\Users\iphernan\Downloads\Personal\EverNote\Quotes\quotes_combined.md"

# 2. Grab all Markdown files in the folder (excluding the output file name if it exists)
$MdFiles = Get-ChildItem -Path $SourceFolder -Filter *.md | Where-Object { $_.FullName -ne $OutputFile }

# 3. Process and merge content with distinct spacing
$MergedContent = foreach ($File in $MdFiles) {
    # Get total file text safely maintaining its structure
    Get-Content -Path $File.FullName -Raw
    
    # Force a clear markdown separator (double newline) between documents
    "`n`n"
}

# 4. Write everything cleanly to the new document
$MergedContent | Set-Content -Path $OutputFile -Encoding utf8

Write-Host "Success! Merged $($MdFiles.Count) Markdown files into: $OutputFile" -ForegroundColor Green
